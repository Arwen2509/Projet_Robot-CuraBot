# 3D Models

This folder contains all 3D models for the CuraBot project.

## Description
The 3D models in this folder are used for the robot components and can be printed using a 3D printer.

## Usage
These files are ready to be used for manufacturing and assembly of the CuraBot.
